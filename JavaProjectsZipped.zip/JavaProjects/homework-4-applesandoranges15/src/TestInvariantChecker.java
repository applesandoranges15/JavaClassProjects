import edu.uwm.cs351.ApptBook;


public class TestInvariantChecker extends ApptBook.TestInvariantChecker {
	// nothing to do.
	
	public void test9() {
		new ApptBook();
	}
}
